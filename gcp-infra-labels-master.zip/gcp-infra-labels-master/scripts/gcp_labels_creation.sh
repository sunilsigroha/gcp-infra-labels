#!/bin/bash

# Function to update labels for a Cloud Storage bucket
update_bucket_labels() {
    local bucket_url="$1"
    local labels="$2"
    local bucket_name=$(echo "$bucket_url" | sed 's/gs:\/\/\([^/]*\)\/.*/\1/')
    
    # Split labels into an array
    IFS=',' read -ra label_array <<< "$labels"
    
    # Loop through each label and update the bucket
    for label in "${label_array[@]}"; do
    echo "gsutil label ch -l $label gs://$bucket_name"
        gsutil label ch -l "$label" gs://"$bucket_name"
    done
}

while true; do
    # Display a menu
    echo "Menu:"
    echo "1. Update project labels"
    echo "2. Update labels for all resources in a service project"
    echo "3. Exit"
    echo "4. press control+c to interrupt for wrong input"
    read -p "Select an option (1/2/3): " OPTION

    case "$OPTION" in
        1)
            # Prompt for the project name
            read -p "Enter the project name: " PROJECT_ID

            # Initialize an array to store label key-value pairs
            declare -A LABELS

            while true; do
                # Prompt for the label key
                read -p "Enter the label key (or 'done' to finish): " LABEL_KEY

                if [ "$LABEL_KEY" == "done" ]; then
                    break
                fi

                # Prompt for the label value
                read -p "Enter the label value for '$LABEL_KEY': " LABEL_VALUE

                # Add the label key-value pair to the array
                LABELS["$LABEL_KEY"]="$LABEL_VALUE"
            done

            # Convert the LABELS array to a label string
            LABEL_STRING=""
            for key in "${!LABELS[@]}"; do
                LABEL_STRING="$LABEL_STRING,$key=${LABELS[$key]}"
            done

            # Remove leading comma from LABEL_STRING
            LABEL_STRING="${LABEL_STRING#,}"

            # Run the gcloud command to update project labels
            gcloud alpha projects update "$PROJECT_ID" --update-labels="$LABEL_STRING"
            ;;
        2)
            # Prompt for the project name
            read -p "Enter the project name: " PROJECT_ID

            # Initialize an array to store label key-value pairs
            declare -A LABELS

            while true; do
                # Prompt for the label key
                read -p "Enter the label key (or 'done' to finish): " LABEL_KEY

                if [ "$LABEL_KEY" == "done" ]; then
                    break
                fi

                # Prompt for the label value
                read -p "Enter the label value for '$LABEL_KEY': " LABEL_VALUE

                # Add the label key-value pair to the array
                LABELS["$LABEL_KEY"]="$LABEL_VALUE"
            done

            # Convert the LABELS array to a label string
            LABEL_VM=""
            LABEL_bucket=""
            for key in "${!LABELS[@]}"; do
                LABEL_VM="$LABEL_VM,$key=${LABELS[$key]}"
                LABEL_bucket="$LABEL_bucket,$key:${LABELS[$key]}"
            done

            # Remove leading comma from LABEL_STRING
            LABEL_VM="${LABEL_VM#,}"
            LABEL_bucket="${LABEL_bucket#,}"

            # Update labels for Compute Engine instances
            gcloud compute instances list --project="$PROJECT_ID" --format="value(name,zone)" | while read -r INSTANCE_NAME ZONE; do
                gcloud compute instances add-labels "$INSTANCE_NAME" --labels="$LABEL_VM" --zone="$ZONE" --project="$PROJECT_ID"
            done

            # Update labels for Cloud Storage buckets individually
            gsutil ls -b -p "$PROJECT_ID" | while read -r BUCKET_URL; do
                update_bucket_labels "$BUCKET_URL" "$LABEL_bucket"
            done
            
             # Update labels for GKE individually
            gcloud container clusters list --project="$PROJECT_ID" --format="value(name,location)" | while read -r CLUSTER_NAME LOCATION; do
                gcloud container clusters update "$CLUSTER_NAME" --update-labels="$LABEL_VM" --location="$LOCATION" --project="$PROJECT_ID" --quiet
            done
            # Update labels for cloud SQL individually
            gcloud sql instances list --project="$PROJECT_ID" --format="value(name)" | while read -r INSTANCE_NAME; do
                gcloud beta sql instances patch "$INSTANCE_NAME" --update-labels="$LABEL_VM" --project="$PROJECT_ID" --quiet
            done
            # update labels for Big Query
            bq ls --project_id="$PROJECT_ID" --format=json | jq -r '.[].datasetReference.datasetId' | while read -r DATASET_ID; do
                bq update --set_label "$LABEL_bucket" "$PROJECT_ID:$DATASET_ID"
            done
                # Update labels for Compute Engine images
            #gcloud compute images list --project="$PROJECT_ID" --format="value(name)" | while read -r IMAGE_NAME; do
            #    gcloud compute images add-labels "$IMAGE_NAME" --labels="$LABEL_VM" --project="$PROJECT_ID" --quiet
            #done

            # Update labels for Compute Engine disks
            gcloud compute disks list --project="$PROJECT_ID" --format="value(name,zone)" | while read -r DISK_NAME ZONE; do
                gcloud compute disks add-labels "$DISK_NAME" --labels="$LABEL_VM" --zone="$ZONE" --project="$PROJECT_ID" --quiet
            done

            # Update labels for Compute Engine snapshots
            gcloud compute snapshots list --project="$PROJECT_ID" --format="value(name)" | while read -r SNAPSHOT_NAME; do
                gcloud compute snapshots add-labels "$SNAPSHOT_NAME" --labels="$LABEL_VM" --project="$PROJECT_ID" --quiet
            done
         
            # Update labels for Google Functions
            #   gcloud functions list --project="$PROJECT_ID" --format="value(name)" | while read -r FUNCTION_NAME; do
            #     gcloud functions deploy "$FUNCTION_NAME" --update-labels="$LABEL_VM" --project="$PROJECT_ID" --quiet
            # done
            #  # Update labels for Cloud Run services
            # gcloud run services list --platform=managed --project="$PROJECT_ID" --format="value(metadata.name, region)" | while read -r SERVICE_NAME region; do
            #     gcloud run services update "$SERVICE_NAME" --region="$region" --update-labels="$LABEL_VM" --platform=managed --project="$PROJECT_ID" --quiet
            # done
            ;;    
        3)
            echo "Exiting the script."
            exit 0
            ;;
        *)
            echo "Invalid option. Please select a valid option."
            ;;
	        esac
done

