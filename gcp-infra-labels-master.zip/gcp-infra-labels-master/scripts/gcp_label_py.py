#!/bin/bash

import subprocess
import shlex
import pandas as pd
import json
import base64
import time









df=pd.DataFrame()
raw={"Project":"","Type":"", "Principal":"","Role":""}

path="/home/jatin_kumar/label/gcp-infra-labels/scripts"

df=pd.read_excel(f"{path}/project_options_project-data.xlsx")

columns_to_check = [
    "Service_Project",
    "Compute_Instance",
    "Kubernetes",
    "Cloud_SQL",
    "Instance_Disk",
    "Big_Query",
    "Instance_Snapshot",
    "Cloud_Storage",
]

# Create the missing columns with empty values
for column in columns_to_check:
    if column not in df.columns:
        df[column] = ""

keys=["app","owner","region","cost-center","env","servicenow-support-group"]
completed=[]

# For each project id in the list, get the iam details
for cluster_row in  df.index:
    # print(cluster_row)
    project_id=df["project_id"][cluster_row]
    print(project_id)
    # project_id="infra-check-project"
    # project_id="qf-project"
    # project_id="app-hubadmin-dv-2gu9"


    if project_id in completed:
        continue
    LABEL_Bucket=""
    LABEL_VM=""

    for i in keys:
        try:
            LABEL_Bucket += i+":"+df[i][cluster_row]+","
            LABEL_VM += i+"="+df[i][cluster_row]+","
        except:
            continue

    LABEL_Bucket = ','.join(LABEL_Bucket.split(',')[:-1])
    LABEL_VM = ','.join(LABEL_VM.split(',')[:-1])
            # Run the gcloud command to update project labels
################################## project labels ##################################
    df["Service_Project"][cluster_row]="completed"
    project_list_command = "gcloud alpha projects update {0} --update-labels={1} --quiet".format(project_id,LABEL_VM)
    try:
        project_output = subprocess.check_output(shlex.split(project_list_command))  
    except:
        print("project not completed")
        df["Service_Project"][cluster_row]="Not completed"
    df.to_excel(f"{path}/project_options_project-data.xlsx",index=False)

    

# # ################################## VM Instrance labels ##################################
    df["Compute_Instance"][cluster_row]="completed"

    instance_list_command = "gcloud compute instances list --project={0} --format='value(name,zone)'".format(project_id)
    instance_output = subprocess.check_output(shlex.split(instance_list_command))
    instance_output_list = instance_output.decode('utf-8').split('\n')[:-1]
    # print(instance_output_json)
    for i  in instance_output_list:
        name, zone = i.split('\t')
        print(name,zone)
        try:
            print(LABEL_VM)
            instance_apply_command = "gcloud compute instances add-labels {0} --labels={1} --zone={2} --project={3}".format( name,LABEL_VM, zone, project_id)
            instance_apply_output = subprocess.check_output(shlex.split(instance_apply_command))
        except Exception as e:
            print("instnace not completed")  
            df["comments"][cluster_row]=str(df["comments"][cluster_row])+f"\n{str(e)}"
            df["Compute_Instance"][cluster_row]="Not completed"
    if len(instance_output_list)==0:
        df["Compute_Instance"][cluster_row]="Not completed"
        df["comments"][cluster_row]=str(df["comments"][cluster_row])+"\n Compute_Instance is empty/ Compute_Instance  API is not enabled"
    df.to_excel(f"{path}/project_options_project-data.xlsx",index=False)




# # ################################## Storage labels ##################################

    df["Cloud_Storage"][cluster_row]="completed"
    
    storage_list_command = "gsutil ls -b -p {0}".format(project_id)
    storage_output = subprocess.check_output(shlex.split(storage_list_command))
    storage_list = storage_output.decode('utf-8').split('\n')[:-1]
    print(storage_list)
    for i  in storage_list:
        print("gsutil label ch -l {0} {1}".format( LABEL_Bucket,i))
        for j in LABEL_Bucket.split(","):
            try:
                storage_apply_command = "gsutil label ch -l '{0}' {1}".format( j,i)
                storage_apply_output = subprocess.check_output(shlex.split(storage_apply_command))
            except Exception as e:
                print("storage not completed")  
                df["comments"][cluster_row]=str(df["comments"][cluster_row])+f"\n{str(e)}"
                df["Cloud_Storage"][cluster_row]="Not completed"
    if len(storage_list)==0:
        df["Cloud_Storage"][cluster_row]="Not completed"
        df["comments"][cluster_row]=str(df["comments"][cluster_row])+"\n Cloud Storage is empty/ Cloud Storage API is not enabled"
 
    df.to_excel(f"{path}/project_options_project-data.xlsx",index=False)
    

# # ################################## GKE labels ##################################

    df["Kubernetes"][cluster_row]="completed"

    gke_list_command = "gcloud container clusters list --project={0} --format='value(name,location)'".format(project_id)
    gke_output = subprocess.check_output(shlex.split(gke_list_command))
    gke_list = gke_output.decode('utf-8').split('\n')[:-1]
    print(gke_list)
    for i  in gke_list:
        name, location = i.split('\t')
        try:
            print("gcloud container clusters update {0} --update-labels={1} --location={2} --project={3} --quiet".format(name,LABEL_VM,location,project_id))
            gke_apply_command = "gcloud container clusters update {0} --update-labels={1} --location={2} --project={3} --quiet".format(name,LABEL_VM,location,project_id)
            gke_apply_output = subprocess.check_output(shlex.split(gke_apply_command))
        except Exception as e:
            print("Kubernetes not completed")
            df["comments"][cluster_row]=str(df["comments"][cluster_row])+f"\n{str(e)}"
            df["Kubernetes"][cluster_row]="Not completed"
    if len(gke_list)==0:
        df["Kubernetes"][cluster_row]="Not completed"
        df["comments"][cluster_row]=str(df["comments"][cluster_row])+"\n Kubernetes is empty/ Kubernetes API is not enabled"
    
    df.to_excel(f"{path}/project_options_project-data.xlsx",index=False)
    
# # ################################## SQL labels ##################################

    df["Cloud_SQL"][cluster_row]="completed"

    sql_list_command = "gcloud sql instances list --project={0} --format='value(name)'".format(project_id)
    sql_output = subprocess.check_output(shlex.split(sql_list_command))
    sql_list = sql_output.decode('utf-8').split('\n')[:-1]
    print(sql_list)
    for i  in sql_list:
        try:
            print("gcloud beta sql instances patch {0} --update-labels={1} --project={2} --quiet".format(i,LABEL_VM,project_id))
            sql_apply_command = "gcloud beta sql instances patch {0} --update-labels={1} --project={2} --quiet".format(i,LABEL_VM,project_id)
            sql_apply_output = subprocess.check_output(shlex.split(sql_apply_command))
        except Exception as e:
            print("sql not completed")
            df["comments"][cluster_row]=str(df["comments"][cluster_row])+f"\n{str(e)}"
            df["Cloud_SQL"][cluster_row]="Not completed"
    if len(sql_list)==0:
        df["Cloud_SQL"][cluster_row]="Not completed"
        df["comments"][cluster_row]=str(df["comments"][cluster_row])+"\n Cloud_SQL is empty/ Cloud_SQL API is not enabled"
    df.to_excel(f"{path}/project_options_project-data.xlsx",index=False)

# # ################################## Big Query labels ##################################

    df["Big_Query"][cluster_row]="completed"
    bq_list_command = "bq ls --project_id={0} --format=json".format(project_id)
    bq_output = subprocess.check_output(shlex.split(bq_list_command))
    print(bq_output)
    
    bq_list = bq_output.decode('utf-8')
    if len(bq_list)>0:
        bq_list=json.loads(bq_list)
        print(bq_list)

        # if bq_list
        for i  in bq_list:
            # i=json.loads(i)
            print(LABEL_Bucket)
            for j in LABEL_Bucket.split(","):
                try:
                    print("bq update --set_label {0} {1}:{2}".format(j,project_id,i['datasetReference']['datasetId']))
                    bq_apply_command = "bq update --set_label {0} {1}:{2}".format(j,project_id,i['datasetReference']['datasetId'])
                    bq_apply_output = subprocess.check_output(shlex.split(bq_apply_command))
                    
                except Exception as e:
                    print(f"Exception occurred: {str(e)}")
                    print("bq not completed")
                    print(e)
                    df["comments"][cluster_row]=str(df["comments"][cluster_row])+f"\n{str(e)}"
                    df["Big_Query"][cluster_row]="Not completed"
                time.sleep(1)
    else:
        df["Big_Query"][cluster_row]="Not completed"
        df["comments"][cluster_row]=str(df["comments"][cluster_row])+"\nBig Query is empty/ Big Query API is not enabled"
    df.to_excel(f"{path}/project_options_project-data.xlsx",index=False)


# ################################## DISK labels ##################################

    df["Instance_Disk"][cluster_row]="completed"

    disk_list_command = "gcloud compute disks list --project={0} --format='value(name,zone)'".format(project_id)
    disk_output = subprocess.check_output(shlex.split(disk_list_command))
    disk_list = disk_output.decode('utf-8').split('\n')[:-1]

    for i  in disk_list:
        name, location = i.split('\t')
        try:
            print("gcloud compute disks add-labels {0} --labels={1} --zone={2} --project={3} --quiet".format(name,LABEL_VM,location,project_id))
            disk_apply_command = "gcloud compute disks add-labels {0} --labels={1} --zone={2} --project={3} --quiet".format(name,LABEL_VM,location,project_id)
            disk_apply_output = subprocess.check_output(shlex.split(disk_apply_command))
        except Exception as e:
            print("disk not completed")
            df["comments"][cluster_row]=str(df["comments"][cluster_row])+f"\n{str(e)}"
            df["Instance_Disk"][cluster_row]="Not completed"
    if len(disk_list)==0:
        df["Instance_Disk"][cluster_row]="Not completed"
        df["comments"][cluster_row]=str(df["comments"][cluster_row])+"\n Instance_Disk is empty/ Instance_Disk API is not enabled"
    df.to_excel(f"{path}/project_options_project-data.xlsx",index=False)



# ################################## Snapshot labels ##################################

    df["Instance_Snapshot"][cluster_row]="completed"

    snapshot_list_command = "gcloud compute snapshots list --project={0} --format='value(name)'".format(project_id)
    snapshot_output = subprocess.check_output(shlex.split(snapshot_list_command))
    snapshot_list = snapshot_output.decode('utf-8').split('\n')[:-1]
    for i  in snapshot_list:
        try:
            print("gcloud compute snapshots add-labels {0} --labels={1} --project={2} --quiet".format(i,LABEL_VM,project_id))
            snapshot_apply_command = "gcloud compute snapshots add-labels {0} --labels={1} --project={2} --quiet".format(i,LABEL_VM,project_id)
            snapshot_apply_output = subprocess.check_output(shlex.split(snapshot_apply_command))
        except Exception as e:
            print("Snapshot not completed")
            df["comments"][cluster_row]=str(df["comments"][cluster_row])+f"\n{str(e)}"
            df["Instance_Snapshot"][cluster_row]="Not completed"
    if len(snapshot_list)==0:
        df["Instance_Snapshot"][cluster_row]="Not completed"
        df["comments"][cluster_row]=str(df["comments"][cluster_row])+"\n Instance_Snapshot is empty/ Instance_Snapshot API is not enabled"
    df.to_excel(f"{path}/project_options_project-data.xlsx",index=False)

            
#                 # Update labels for Compute Engine images
#             #gcloud compute images list --project="$PROJECT_ID" --format="value(name)" | while read -r IMAGE_NAME; do
#             #    gcloud compute images add-labels "$IMAGE_NAME" --labels="$LABEL_VM" --project="$PROJECT_ID" --quiet
#             #done



#             # Update labels for Google Functions
#             #   gcloud functions list --project="$PROJECT_ID" --format="value(name)" | while read -r FUNCTION_NAME; do
#             #     gcloud functions deploy "$FUNCTION_NAME" --update-labels="$LABEL_VM" --project="$PROJECT_ID" --quiet
#             # done
#             #  # Update labels for Cloud Run services
#             # gcloud run services list --platform=managed --project="$PROJECT_ID" --format="value(metadata.name, region)" | while read -r SERVICE_NAME region; do
#             #     gcloud run services update "$SERVICE_NAME" --region="$region" --update-labels="$LABEL_VM" --platform=managed --project="$PROJECT_ID" --quiet

# done
